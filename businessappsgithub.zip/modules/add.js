function add (fn,sn){
   
    const c=fn+sn;
    return (c)
}
 const sub = (fn,sn)=>{

    const c=fn-sn;
    return (c)
 }



 module.exports={add,sub};