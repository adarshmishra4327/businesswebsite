module.exports ={
    mongourl:process.env.mongourl
}