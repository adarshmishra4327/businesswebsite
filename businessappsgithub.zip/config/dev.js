module.exports ={
    mongourl:"mongodb+srv://adarsh:Aimoflife@cluster0-mo5g4.mongodb.net/test?retryWrites=true&w=majority"
}